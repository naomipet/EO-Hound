/**
 * server.js
 *
 * Works in the local development environment and when deployed. If successful,
 * shows a single web page with the SRTM DEM displayed in a Google Map. See
 * accompanying README file for instructions on how to set up authentication.
 */
const ee = require('@google/earthengine');
const express = require('express');
const handlebars  = require('express-handlebars');


const app = express()
  .engine('.hbs', handlebars({extname: '.hbs', cache: false}))
  .set('view engine', '.hbs')
  .use('/static', express.static('static'))

  app.get('/', (request, response) => {

    const prop = "bbb";
    var mapid = 0;
    var token = 0;
    response.render('index', {prop, mapid, token} );
  });

  app.get('/filter/:collectionSource/:startDate/:finishDate/:maxCloud/:geometry', (request, response) => {

     var res = request.params.geometry.split(",");
     var geo =[];
     for (var i = 0; i < 4; i++)
     {
       geo.push([parseFloat(res[2*i]), parseFloat(res[2*i+1])]);
     }
    var poly = ee.Geometry.Polygon(geo);
    var bbox = ee.FeatureCollection(poly);
    //var date = request.params.startDate.split('-')
    var start = ee.Date(request.params.startDate)
    var finish = ee.Date('2018-03-01')
    collectionSource = '';
    switch(request.params.collectionSource) {
      case 'Landsat': //not operational!
        collectionSource = 'LANDSAT/LC08/C01/T1_SR';
        break;
      case 'Sentinel2A':
        collectionSource = 'COPERNICUS/S2_SR';
        break;
      default:
        collectionSource = 'COPERNICUS/S2';
    }
    maxCloud = parseInt(request.params.maxCloud)
    var collection = ee.ImageCollection(collectionSource).filterBounds(bbox).filterDate(start,finish).filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', maxCloud))
    var bboxArea = bbox.geometry().area().divide(100 * 100).getInfo();
    var sentinelFootprint = ee.FeatureCollection('users/naomipet/sentinel2_tiles_world').filterBounds(bbox);
    var empty = ee.Image().byte();
    var outline = empty.paint({
      featureCollection: sentinelFootprint,
      width: 2
    });

    /***** Filter clouds and clip to bbox *****/

    var filteredCollection = collection.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 15))
                    .map(function(im){return im.clip(bbox)})
    var count = collection.size();
    var prop
    if(count.getInfo() == '0'){
      prop = 'no images'
      response.render('index', {prop} );
    }
    else {
      //get area coverage
      var covarage = GetCoverage(sentinelFootprint, bbox, bboxArea);
      var granuleNames = sentinelFootprint.aggregate_array("Name")
      //calc statistics
      var areas = covarage.aggregate_array("areaHa")
      var clouds = collection.aggregate_array('CLOUDY_PIXEL_PERCENTAGE');

      // Get the date range of images in the collection.
      var range = collection.reduceColumns(ee.Reducer.minMax(), ["system:time_start"])
      var minDate = ee.Date(range.get('min'))
      var maxDate = ee.Date(range.get('max'))

      prop = "areas: " + areas.getInfo() + " clouds: "+ clouds.getInfo() + "count: " + count.getInfo() + "minDate: " + minDate.format('d-M-Y').getInfo() + " maxDate: " + maxDate.format('d-M-Y').getInfo() + "names: " + granuleNames.getInfo();
      var mapid1 =[];
      var token1 =[];
      //get maps tokens and respond
      filteredCollection.getMap({min: 0, max: 3000}, ({mapid, token}) => {
        mapid1.push(mapid.toString());
        token1.push(token.toString());
        outline.getMap({palette: '871f34'}, ({mapid, token}) => {
          mapid1.push(mapid.toString());
          token1.push(token.toString());
        response.render('index', {prop, mapid1, token1} );
        })
      })
    }

});




// Private key, in `.json` format, for an Earth Engine service account.
const PRIVATE_KEY = require('./privatekey.json');
const PORT = process.env.PORT || 3000;

ee.data.authenticateViaPrivateKey(PRIVATE_KEY, () => {
  ee.initialize(null, null, () => {
    app.listen(PORT);
    console.log(`Listening on port ${PORT}`);
  });
});



//utils
GetCoverage = function(geomeries, bbox, bboxArea) {
  /*gets the coverage precentage of a bbox in a feature*/
  return ee.FeatureCollection(geomeries.map(function(feature) {
    var inter = feature.intersection(bbox.geometry());
    var featureInt = ee.Feature(inter);
    return feature.set({areaHa: featureInt.geometry().area().divide(100).divide(bboxArea)});
  }));
};

GetDayDif = function(dateList) {
  var li= ee.List([])
  var lastDayIndex = dateList.size().add(-1);
  var difList = ee.List.sequence(0, lastDayIndex).map(function(n){
    var e = ee.Number(n).add(-1);
    var date = ee.Date(dateList.get(n));
    var dif = date.difference(dateList.get(e), 'day');
    return  ee.Algorithms.If(n, dif, 0);
  })
  return RemoveZerosFromList(difList);
}

RemoveZerosFromList = function(list){
  var mappingFunc = function(item, newlist) {
    newlist = ee.List(newlist)
    return ee.List(ee.Algorithms.If(item, newlist.add(item), newlist))
  }
  return ee.List(list.iterate(mappingFunc, ee.List([])))
}

GetImageDates = function(collection) {
  return ee.List(collection.toList(collection.size()).map(function(img){
    return ee.Image(img).date().format()
  }))
}
